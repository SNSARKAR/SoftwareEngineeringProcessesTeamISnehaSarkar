import static org.junit.Assert.*;

import org.junit.Test;

public class FractionTest {
//This test function is traceable to R02,R03,R04 and R05
	@Test
	public void testGreatestCommonFactor() {
	int num, den;
	num = 12;den=18;
	assertEquals(6,Fraction.greatestCommonFactor(num, den));
	assertNotEquals(12,Fraction.greatestCommonFactor(num, den));
	}
//This test function is traceable to R02,R03,R04 and R05
	@Test
	public void testFindFraction() {
	double frac =0.25; 
	assertEquals("1/4",Fraction.findFraction(frac));
	assertNotEquals("0.25",Fraction.findFraction(frac));
	}
}
