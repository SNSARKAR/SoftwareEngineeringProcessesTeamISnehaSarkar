import java.util.Scanner;

public class FunctionF9 {
  public static double diff(double a, double b) {
    return (a > b) ? (a - b) : (b - a);
  }

  // The function below returns the result of x^n.
  /**
   * 
   * @param x is the value to be raised.
   * @param n is the power to which x is raised to.
   * @return power
   */
  public static double findPow(double x, int n) {

    if (n == 0) {
      return 1;
    }

    if (n == 1) {
      return x;
    }

    if (n % 2 == 0) {
      return findPow(x, n / 2) * findPow(x, n / 2);
    } else {
      return findPow(x, n / 2) * findPow(x, n / 2) * x;
    }
  }

  /**
   * 
   * @param x  is the value to be raised.
   * @param n is the power to which x is raised to.
   * @param val
   * @return
   */
  public static double function(double x, int n, double val) {
    return findPow(x, n) - val;
  }

  // x is the value to be raised.
  // n is the power to which x is raised to.
  // f'(x) taken in the question
  public static double function_derivative(double x, int n, double val) {

    if (n == 1) {
      return 1;
    }
    return n * findPow(x, n - 1);
  }

  // driving function which calculates the nth-root of number,where n is an
  // integer value without fractional part
  /**
   * 
   * @param val contains the value whose nth-root has to be calculated
   * @param error value helps in maintaining the precision of the root value
   * @return
   */
  public static double find_root(double val, int n, double error) {
    double previous_root = 2.0;
    double root = previous_root - 
        function(previous_root, n, val) / function_derivative(previous_root, n, val);
    while (diff(root, previous_root) >= error) {
      previous_root = root;
      root = previous_root 
          - function(previous_root, n, val) / 
          function_derivative(previous_root, n, val);
    }
    return root;
  }

  /**
   * 
   * @param x is the value to be raised.
   * @param y is the power to which x is raised to,y can be a real number with or without a fractional part.
   * @return
   */
  public static double calculateResultOfFunction(double x, String y) {
    int pos = y.indexOf('.');
    double result = 0;
    if (pos == -1) {
      int temp = Integer.parseInt(y);
      if (temp > 0) {
        result = findPow(x, temp);
      } else {
        result = 1 / findPow(x, (-1 * temp));
      }
    } else {
      int y1 = 0;
      int y2 = 0;
      double result1 = 0;
      double result2 =0; 
      double result3=0;
      y1 = Integer.parseInt(y.substring(0, pos));
      y2 = Integer.parseInt(y.substring(pos + 1));
      result1 = 1.0;
      result2 = 1.0;
      result1 = findPow(x, y1);
      result2 = findPow(x, y2);
      int decimal_value = 10;
      double error = 10;
      for (int i = 0; i < decimal_value; i++) {
        {
          error /= 10;
        }
      }
      if (String.valueOf(y2).length() == 1) {
        result3 = find_root(result2, 10, error);
      } else if (String.valueOf(y2).length() == 2) {
        result3 = find_root(result2, 100, error);
      } else if (String.valueOf(y2).length() == 3) {
        result3 = find_root(result2, 1000, error);
      }
      if (Double.parseDouble(y) > 0) {
        result = result1 * result3;
      } else {
        result = 1 / (result1 * result3);
      }
    }
    return result;
  }
/**
 * 
 *
 * @param x is the value to be raised.
   * @param y is the power to which x is raised to,y can be a real number with or without a fractional part.
   * @return the final result or appropriate error message.
 */
  public static String findResult(double x, String y) {
    double result = 0;
    double temp = Double.parseDouble(y);
    if (x < 0 && (temp - (int) temp) != 0) {
      return ("Result is undefined, as the program cannot handle complex numbers.");
    } else {
      if (x == 1 || x == -1) {
        result = calculateResultOfFunction(x, y);
      } else if (Double.parseDouble(y) == 1) {
        result = x;
      } else if (Double.parseDouble(y) == -1) {
        result = 1 / x;
      } else if (Double.parseDouble(y) == 0 && x != 0) {
        result = 1;
      } else {
        result = calculateResultOfFunction(x, y);
      }
      if (String.valueOf(result) == "NaN") {
        double yTemp = Double.parseDouble(y);
        String s = Fraction.findFraction(yTemp);
        int yTemp1, yTemp2, pos;
        int pos1 = s.indexOf('/');
        yTemp1 = Integer.parseInt(s.substring(0, pos1));
        yTemp2 = Integer.parseInt(s.substring(pos1 + 1));
        if (yTemp1 > 0 && yTemp2 <= 99) {
          if (yTemp2 > 0 && yTemp2 <= 100) {
            result = findPow(x, yTemp1);
          }
          result = find_root(result, yTemp2, 0.000000001);
        }
        if (String.valueOf(result) == "NaN") {
          return ("The result value is undefined,as the value of the function for the calculation is too large to handled.");
        } else {
          return ("The result of the function is " + result + ".");
        }
      } else if (String.valueOf(result) == "Infinity" ||String.valueOf(result) == "-Infinity" ) {
        return ("The result is " + result + " ,which is computed for"
            + " a large value for the result and is almost equal to infifnity.");
      } else {
        return ("The result of the function F9: x^y is " + result + ".");
      }
    }
  }

  public static String resultOfFunctionF9(String x, String y) {

    String result = "";
    boolean flag1, flag2;
    flag1 = flag2 = false;
    for (int i = 0; i < x.length(); i++) {
      if ((x.charAt(i) >= '0' && x.charAt(i) <= '9') || (x.charAt(i) == '.') || (x.charAt(i) == '-')) {
        flag1 = true;
      } else {
        flag1 = false;
        break;
      }
    }
    for (int i = 0; i < y.length(); i++) {
      if ((y.charAt(i) >= '0' && y.charAt(i) <= '9') || (y.charAt(i) == '.') || (y.charAt(i) == '-')) {
        flag2 = true;
      } else {
        flag2 = false;
        break;
      }
    }

    if (flag1 == false || flag2 == false) {
      if (flag1 == false && flag2 == false) {
        System.out.println("The input values of x and y are not proper,they are non-numeric values.");
        result = "InputError";
      } else if (flag2 == false) {
        System.out.println("The input value of y is not proper,it is a non-numeric value.");
        result = "InputError";
      } else {
        System.out.println("The input value of x is not proper,it is a non-numeric value.");
        result = "InputError";
      }
    } else {
      result = findResult(Double.parseDouble(x), y);

    }
    return result;
  }

  // x is the value to be raised.
  // y is the power to which x is raised to,y can be a real number with or
  // without a fractional part.
  public static void main(String[] args) {
    System.out.println("Calculator for Function F9 :x^y");
    System.out.println("x is the value which has to be raised to another value between the range from -1000 to 1000 upto two digits after the decimal point ");
    System.out.println("y is the value to which another value is raised to and value of y should be in the range from -100 to 100 upto one digit after the decimal point");
    Scanner scan = new Scanner(System.in);
    char choice = '\0';
    boolean flag = true;
    while (flag) {
      try{
      System.out.println(
          "Enter the value of x,in the range from -1000 to 1000 and upto two digits after decimal point:");
      String x = scan.nextLine();
      System.out.println(
          "Enter the value of y,in the range from -100 to 100 upto one digit after the decimal point :");
      String y = scan.nextLine();
      String result = resultOfFunctionF9(x, y);
      if (result == "InputError") {
        System.out.print("Please,Re-enter the input values.");
        continue; }
      else{
        System.out.println(result); }
      System.out.println("----------------------------------------------------------------");
      System.out.println("Do you wish to continue with another calculation?If yes then enter 'Y' or 'y'");
      System.out.println("If you do not wish to continue, enter 'N' or 'n'");
      choice = scan.nextLine().trim().charAt(0);
      if (choice == 'N' || choice == 'n') {
        flag = false;
        System.out.println("GoodBye!");
       
      } else {
        flag = true;
      }
    }
      catch(Exception e){
        System.out.println("An error was encountered.please,Re-enter the input values.");
        continue;
      }
    }
  }
}
