import static org.junit.Assert.*;

import org.junit.Test;

public class FunctionF9Test {
//This test function is traceable to R02,R03,R04 and R05
  @Test
  public void testdiff() {
    double a,b;
    a=3;
    b = 4.5;
    assertNotEquals(1,FunctionF9.diff(a, b));
    assertEquals(1.5,FunctionF9.diff(a, b),0);
  }
  @Test
  //This test function is traceable to R02,R03,R04 and R05
  public void testPow(){
    double x = 4.5;
    int n1,n2,n3,n4;
    n1=0;n2=1;n3=4;n4=7;
    assertEquals(1.0,FunctionF9.findPow(x, n1),0);
    assertEquals(4.5,FunctionF9.findPow(x, n2),0);
    assertEquals(410.0625,FunctionF9.findPow(x, n3),0);
    assertEquals(37366.9453125,FunctionF9.findPow(x, n4),0);
    assertNotEquals(4.5,FunctionF9.findPow(x, n1),0);
    assertNotEquals(1.0,FunctionF9.findPow(x, n2),0);
    assertNotEquals(37366.9453125,FunctionF9.findPow(x, n3),0);
    assertNotEquals(410.0625,FunctionF9.findPow(x, n4),0);

  }
//This test function is traceable to R02,R03,R04 and R05
  @Test 
  public void testFunction(){
    assertEquals(1018.9,FunctionF9.function(2.0, 10, 5.1),0);
    assertNotEquals(1018.9,FunctionF9.function(2.0, 100, 5.1),0);
  }
//This test function is traceable to R02,R03,R04 and R05
  @Test
  public void testFunction_Derivative(){
    assertEquals(9,FunctionF9.function_derivative(4.5, 2, 0),0);
    assertEquals(1,FunctionF9.function_derivative(6.9, 1, 0),0);
    assertNotEquals(1018.9,FunctionF9.function_derivative(4.5, 2, 0),0);
  }
//This test function is traceable to R02,R03,R04,R05 and R06
  @Test
  public void testFind_Root(){
    double x = 12.1;
    int n1,n2,n3;
    n1= 2;
    n2=10;
    n3 =3;
    double error =  0.000000001;
    assertEquals(1.2831532758561022,FunctionF9.find_root(x, n2,error),0);
    assertEquals(3.4785054261852175,FunctionF9.find_root(x, n1, error),0);
    assertNotEquals(1018.9,FunctionF9.function_derivative(x, n3, error),0);
  }
  @Test
  //This test function is Traceable to R02,R03,R04,R05 and R06.
  public void testcalculateResultOfFunction(){
    double x1 = 2.45;double x2= 81;double x3 = 1.2;
    String y1,y2,y3,y4,y5,y6,y7;
    y1 = "3";y2 = "-2";y3 ="1.25";y4 = "-2.22";y5 = "0.25";y6="5.2";y7="0.006";

    assertEquals(14.706125000000004,FunctionF9.calculateResultOfFunction(x1, y1),0);
    assertEquals(0.16659725114535606,FunctionF9.calculateResultOfFunction(x1, y2),0);
    assertEquals(3.0651914498868975,FunctionF9.calculateResultOfFunction(x1, y3),0);
    assertEquals(0.136789037188514,FunctionF9.calculateResultOfFunction(x1, y4),0);
    assertNotEquals(3.1233,FunctionF9.calculateResultOfFunction(x2, y5),0);
    assertEquals(2.580729459802168,FunctionF9.calculateResultOfFunction(x3, y6),0);
    assertEquals(1.1156006217298275,FunctionF9.calculateResultOfFunction(x3, y7),0);
  }
  @Test
  ////This test function is traceable to R01,R02 and R07
  public void testfindResult(){
    double x1,x2,x3,x4,x5,x6,x7;
    String y1,y2,y3,y4,y5,y6,y7,y8,y9;
    x1 = -10.5;x2 =1;x3 =2.3;x4 = 2.5;x5 = 81;x6 = 1001.25;x7=100.05;
    y1 ="2.3";y2 = "-5.3";y3="1";y4 = "-1";y5 ="0";y6 = "1.44";y7="0.25";y8="11.25";y9 ="999.9";
    assertEquals("Result is undefined, as the program cannot handle complex numbers.",FunctionF9.findResult(x1, y1));
    assertNotEquals("The result of the func;tion F9: x^y is -1.0.",FunctionF9.findResult(x2, y2));
    assertEquals("The result of the function F9: x^y is -10.5.",FunctionF9.findResult(x1, y3));
    assertEquals("The result of the function F9: x^y is 0.4347826086956522.",FunctionF9.findResult(x3, y4));
    assertEquals("The result of the function F9: x^y is 1.0.",FunctionF9.findResult(x3, y5));
    assertEquals("The result of the function F9: x^y is 3.741395439109407.",FunctionF9.findResult(x4, y6));
    assertEquals("The result of the function is 3.0.",FunctionF9.findResult(x5, y7));
    assertEquals("The result value is undefined,as the value of the function for the calculation is too large to handled.",FunctionF9.findResult(x6, y8));
    assertEquals("The result is Infinity ,which is computed for a large value for the result and is almost equal to infifnity.",FunctionF9.findResult(x7, y9));


  }
//This test function is traceable to R01.
  @Test
  public void testresultOfFunctionF9(){
    String x1,x2,x3;
    String y1,y2,y3;
    x1 ="2$33a";x2 ="1.45";
    y1 ="5.4a";y2 ="1.5";
    assertNotEquals("The input value of y is not proper,it is a non-numeric value.",FunctionF9.resultOfFunctionF9(x2, y2));
    assertEquals("InputError",FunctionF9.resultOfFunctionF9(x1, y2));
    assertEquals("InputError",FunctionF9.resultOfFunctionF9(x2, y1));
    assertEquals("InputError",FunctionF9.resultOfFunctionF9(x1, y1));
    assertEquals("The result of the function F9: x^y is 1.7460312139248828.",FunctionF9.resultOfFunctionF9(x2, y2));
  }
}



