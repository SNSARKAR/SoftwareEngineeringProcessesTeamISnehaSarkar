To run the file on command line prompt :
1.Open the command line prompt
2.Navigate to the folder with the jar file
3.Type "java -jar Function9.jar"

To run the test cases for the FunctionF9 class:
1. run the class FunctionF9Test.java 

To run the source code for the FunctionF9 class:
1. run the class FunctionF9.java 

