import java.util.Scanner;

public class FunctionF9 {
	public static double diff(double a, double b) {
		return (a > b) ? (a - b) : (b - a);
	}

	// x is the value to be raised.
	// n is the power to which x is raised to.
	// The function below returns the result of x^n.
	public static double find_pow(double x, int n) {

		if (n == 0) {
			return 1;
		}

		if (n == 1) {
			return x;
		}

		if (n % 2 == 0) {
			return find_pow(x, n / 2) * find_pow(x, n / 2);
		} else {
			return find_pow(x, n / 2) * find_pow(x, n / 2) * x;
		}
	}

	// x is the value to be raised.
	// n is the power to which x is raised to.
	public static double function(double x, int n, double val) { 
		return find_pow(x, n) - val;
	}

	//x is the value to be raised.
	// n is the power to which x is raised to.
	// f'(x) taken in the question
	public static double function_derivative(double x, int n, double val) { 

		if (n == 1) {
			return 1;
		}
		return n * find_pow(x, n - 1);
	}

	// val contains the value whose nth-root has to be calculated
	// error value helps in maintaining the precision of the root value
	// driving function which calculates the nth-root of number,where n is an
	// integer value without fractional part
	public static double find_root(double val, int n, double error) {
		double previous_root = 2.0;
		double root = previous_root - function(previous_root, n, val) / function_derivative(previous_root, n, val);
		while (diff(root, previous_root) >= error) {
			previous_root = root;
			root = previous_root - function(previous_root, n, val) / function_derivative(previous_root, n, val);
		}
		return root;
	}

	// x is the value to be raised.
	// y is the power to which x is raised to,y can be a real number with or
	// without a fractional part.
	public static double calculateResultOfFunction(double x, String y) {
		int pos = y.indexOf('.');
		double result = 0;
		if (pos == -1) {
			int temp = Integer.parseInt(y);
			if (temp > 0) {
				result = find_pow(x, temp);
			} else {
				result = 1 / find_pow(x, (-1 * temp));
			}
		} else {
			int y1, y2;
			double result1, result2, result3;
			result1 = result2 = result3 = 0;
			y1 = Integer.parseInt(y.substring(0, pos));
			y2 = Integer.parseInt(y.substring(pos + 1));
			result1 = 1.0;
			result2 = 1.0;
			result1 = find_pow(x, y1);
			result2 = find_pow(x, y2);
			int decimal_value = 10;
			double error = 10;
			for (int i = 0; i < decimal_value; i++){
				{
					error /= 10;
				}
			}
			if (String.valueOf(y2).length() == 1) {
				result3 = find_root(result2, 10, error);
			} else if (String.valueOf(y2).length() == 2) {
				result3 = find_root(result2, 100, error);
			} else if (String.valueOf(y2).length() == 3) {
				result3 = find_root(result2, 1000, error);
			}
			if (Double.parseDouble(y) > 0) {
				result = result1 * result3;
			} else {
				result = 1 / (result1 * result3);
			}
		}
		return result;
	}

	public static String findResult(double x, String y) {
		double result = 0;
		double temp = Double.parseDouble(y);
		if (x < 0 && (temp - (int) temp) != 0) {
			return ("Result is undefined, as the program cannot handle complex numbers.");
		} else {
			if (x == 1 || x == -1) {
				result = calculateResultOfFunction(x, y);
			} else if (Double.parseDouble(y) == 1) {
				result = x;
			} else if (Double.parseDouble(y) == -1) {
				result = 1 / x;
			} else if (Double.parseDouble(y) == 0 && x != 0) {
				result = 1;
			} else {
				result = calculateResultOfFunction(x, y);
			}
			if (String.valueOf(result) == "NaN") {
				double yTemp = Double.parseDouble(y);
				String s = Fraction.findFraction(yTemp);
				int yTemp1, yTemp2, pos;
				int pos1 = s.indexOf('/');
				yTemp1 = Integer.parseInt(s.substring(0, pos1));
				yTemp2 = Integer.parseInt(s.substring(pos1 + 1));
				if (yTemp1 > 0 && yTemp2 <= 99) {
					if (yTemp2 > 0 && yTemp2 <= 100) {
						result = find_pow(x, yTemp1);
					}
					result = find_root(result, yTemp2, 0.000000001);
				}
				if (String.valueOf(result) == "NaN") {
					return ("The result value is undefined,as the value of the function for the calculation is too large to handled.");
				} else {
					return ("The result of the function is " + result);
				}
			} else if (String.valueOf(result) == "Infinity") {
				return ("The result is " + result
						+ " ,which is computed for"
						+ " a large value for the result and is almost equal to infifnity.");
			} else {
				return ("The result of the function F9: x^y is " + result);
			}
		}
	}

	// x is the value to be raised.
	// y is the power to which x is raised to,y can be a real number with or
	// without a fractional part.
	public static void main(String args[]) {
		Scanner scan = new Scanner(System.in);
		int num, den;
		System.out.println("Enter the value of x,x is the value which has to be raised to another value between the range from 0 to 1000 :");
		String x = scan.nextLine();
		System.out.println("Enter the value of y,y is the value to which another value is raised to and value of y should be upto 1 decimal point :");
		String y = scan.nextLine();
		String result = "";
		boolean flag1, flag2; 
		flag1 = flag2 = false;
		for (int i = 0; i < x.length(); i++) {
			if ((x.charAt(i) >= '0' && x.charAt(i) <= '9') || (x.charAt(i) == '.') ||(x.charAt(i) == '-')) {
				flag1 = true;
			} else {
				flag1 = false;
				break;
			}
		}
		for (int i = 0; i < y.length(); i++) {
			if ((y.charAt(i) >= '0' && y.charAt(i) <= '9') || (y.charAt(i) == '.')||(y.charAt(i) == '-')) {
				flag2 = true;
			} else {
				flag2 = false;
				break;
			}
		}

		if (flag1 == false || flag2 == false){
			if (flag1 == false && flag2 == false){
				System.out.println("The input values of x and y are not proper,they are non-numeric values.");
			} 
			else if (flag2 == false){
				System.out.println("The input value of y is not proper,it is a non-numeric value.");
			} 
			else{
				System.out.println("The input value of x is not proper,it is a non-numeric value.");
			}
		} else {
			result = findResult(Double.parseDouble(x), y);
			System.out.println(result);
		}
	}
}
